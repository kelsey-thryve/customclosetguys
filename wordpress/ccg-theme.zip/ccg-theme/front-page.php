<?php
/* Generated from index.html by tools/build-wp-theme.py. Edit the static page, then re-run the script. */
get_header(); ?>


<section class="hero">
  <div class="wrap">
    <div>
      <p class="eyebrow">Custom closets in Albuquerque and Santa Fe</p>
      <h1>Closets made to fit the room you already have.</h1>
      <p class="lede">Walk-ins, smaller closets and mudrooms, designed around the way you actually use them. Start by seeing yours in your own room: upload a photo and our designer draws it in.</p>
      <div class="cta-row"><a class="btn gold" href="<?php echo ccg_url( 'design' ); ?>">Design your closet in your room</a><a class="btn" href="<?php echo ccg_url( 'contact' ); ?>">Book a free consultation</a></div>
      <p class="hero-meta"><span><strong>Complimentary</strong> onsite design meeting</span><span>Call <strong><a href="tel:+15055461788" style="text-decoration:none">(505) 546-1788</a></strong></span></p>
    </div>
    <div>
      <div class="framed"><img src="<?php echo ccg_asset( 'img/work/walkin-real-bags.jpg' ); ?>" alt="Finished walk-in closet with open shelving for bags and double hanging"></div>
      <dl class="spec"><dt>Project</dt><dd>Walk-in closet</dd><dt>Details</dt><dd>Open shelving for bags and shoes, double hanging, drawer bank</dd><dt>Photo</dt><dd>Custom Closet Guys project</dd></dl>
    </div>
  </div>
</section>
<div class="tagline-band"><div class="wrap"><strong>Save time. Live better. Shop smarter.</strong><span>Proudly serving Albuquerque, Santa Fe and surrounding communities.</span></div></div>

<section class="section mist" id="design">
  <div class="wrap">
    <div class="head-split">
      <div><p class="eyebrow">The design studio</p><h2>See it in your room before anything is built.</h2></div>
      <div>
        <p class="lede">Upload a photo of the wall or closet you want to change, tick the features you need, and get a realistic render of the finished closet in your actual space. Ask the designer for changes in plain words, then send it to us for a quote.</p>
        <div class="studio-points"><div><b>Photo of your space</b>Any phone photo works.</div><div><b>Render in your room</b>Ready in under a minute.</div><div><b>Quote request</b>Your design comes straight to us.</div></div>
      </div>
    </div>

    <div class="steps-pills"><span class="lbl">Preview steps</span><span class="pill on">1. Photo and brief</span><span class="pill">2. Render and refine</span><span class="pill">3. Your details</span><span class="pill">4. Sent</span></div>
    <div class="studio">
      <div>
        <p class="kicker">Step one</p>
        <h3>Show us the space</h3>
        <label class="upload">
          <span class="tag">Sample photo</span>
          <span class="cta">Tap to upload a photo</span>
          <input type="file" accept="image/*" aria-label="Upload a photo of your space">
        </label>
        <p class="hint">Upload a photo of your wall, alcove or closet. For a walk-in, add up to 5 photos from different angles.</p>
      </div>
      <div>
        <p class="kicker">Step two</p>
        <h3>Tell us what you need</h3>
        <div data-for-space="closet">
          <p style="font-size:14px">Add the essentials. Tap any that apply:</p>
          <div class="chips" data-chips>
          <button type="button" class="chip on" aria-pressed="true">Full-height hanging rails</button>
          <button type="button" class="chip on" aria-pressed="true">Bank of soft-close drawers</button>
          <button type="button" class="chip" aria-pressed="false">Open cube shelves</button>
          <button type="button" class="chip on" aria-pressed="true">Dedicated shoe racks</button>
          <button type="button" class="chip on" aria-pressed="true">Integrated LED lighting</button>
          <button type="button" class="chip" aria-pressed="false">Full-length mirror</button>
          </div>
          <label for="st-notes">Anything else? Dimensions, style, finish...</label>
          <textarea id="st-notes">Mostly hanging with 4 drawers and a shoe rack at the base. Finish: white with matte black rods.</textarea>
        </div>
        <a class="btn gold block" style="margin-top:16px" href="<?php echo ccg_url( 'design' ); ?>">Generate my design</a>
      </div>
    </div>
    <p class="note">Concept preview of the real designer, with a sample photo. On the live site the working AI designer loads in this panel: visitors upload their own photo and get a photorealistic render.</p>

  </div>
</section>

<section class="section" id="services">
  <div class="wrap">
    <div class="head-split">
      <div><p class="eyebrow">What we build</p><h2>Every room that holds your things.</h2></div>
      <p class="lede">Each project is measured, designed and built for one space. Pick a room to start a design with it.</p>
    </div>
    <article class="svc" id="walk-in">
      <img src="<?php echo ccg_asset( 'img/work/walkin-island-drawers.jpg' ); ?>" alt="Walk-in closets" loading="lazy">
      <div><h3>Walk-in closets</h3><p>Drawer banks, cabinets, open shelving and hanging space planned around your clothes, bags and shoes.</p></div>
      <a class="link-arrow" href="<?php echo ccg_url( 'design' ); ?>">Design a walk-in</a>
    </article>
    <article class="svc" id="closet">
      <img src="<?php echo ccg_asset( 'img/work/closet-center-drawers.jpg' ); ?>" alt="Smaller closets" loading="lazy">
      <div><h3>Smaller closets</h3><p>A central drawer bank with shelving and hanging on each side, making the most of a compact closet.</p></div>
      <a class="link-arrow" href="<?php echo ccg_url( 'design' ); ?>">Design a closet</a>
    </article>
    <article class="svc" id="mudroom">
      <img src="<?php echo ccg_asset( 'img/work/mudroom-pine-bench.jpg' ); ?>" alt="Mudrooms and entryways" loading="lazy">
      <div><h3>Mudrooms and entryways</h3><p>Benches, coat hooks, drawers and shelving that give bags, coats and shoes a place by the door.</p></div>
      <a class="link-arrow" href="<?php echo ccg_url( 'design' ); ?>">Design a mudroom</a>
    </article>
    <article class="svc" id="garage">
      <div class="ph">[Garage spaces photo from Richard]</div>
      <div><h3>Garage spaces</h3><p>Cabinets, workbenches and wall shelving that turn the garage into an organized space you actually want to use.</p></div>
      <a class="link-arrow" href="<?php echo ccg_url( 'design' ); ?>#garage">Design a garage</a>
    </article>
    <article class="svc" id="cabinetry">
      <div class="ph">[Cabinetry photo from Richard]</div>
      <div><h3>Cabinetry</h3><p>Upper and lower cabinets with countertops, as seen in our gallery. <span class="todo">[Confirm room type: laundry room?]</span></p></div>
      <a class="link-arrow" href="<?php echo ccg_url( 'contact' ); ?>">Ask about cabinetry</a>
    </article>
  </div>
</section>

<section class="section mist" id="process">
  <div class="wrap">
    <div class="head-split">
      <div><p class="eyebrow">Getting started</p><h2>From a photo to a finished closet.</h2></div>
      <p class="lede">It starts with a complimentary design meeting at your home, and nothing gets built until the design is right for you.</p>
    </div>
    <div class="steps">
      <div class="step"><div class="num">1</div><h3>Design meeting</h3><p>A complimentary onsite consultation to talk through your goals, take measurements and outline a plan.</p></div>
      <div class="step"><div class="num">2</div><h3>Design review</h3><p>We turn those goals into a fully customized design, weighing function, budget and added property value.</p></div>
      <div class="step"><div class="num">3</div><h3>Design prep</h3><p>We can bring portable clothes racks and shelves so your wardrobe stays accessible during the build.</p><span class="badge">Optional</span></div>
      <div class="step"><div class="num">4</div><h3>Build</h3><p>From sketching the design on your walls to installing hardware and accessories, our team builds your new closet.</p></div>
      <div class="step"><div class="num">5</div><h3>Enjoy</h3><p>Save time. Live better. Shop smarter.</p></div>
    </div>
    <p style="margin-top:32px;font-size:15px">Want a head start? <a class="link-arrow" style="font-size:15px" href="<?php echo ccg_url( 'design' ); ?>">Design it in your room first</a> and bring the render to your design meeting.</p>
  </div>
</section>

<section class="section" id="work">
  <div class="wrap">
    <div class="head-split">
      <div><p class="eyebrow">Our work</p><h2>Recent closets.</h2></div>
      <p class="lede">A few recent projects, from finished walk-ins and mudrooms to a closet mid-build.</p>
    </div>
    <div class="work-grid">
      <figure class="wide"><img src="<?php echo ccg_asset( 'img/work/walkin-island-skylight.jpg' ); ?>" alt="Walk-in closet with center island and skylight"><figcaption>Walk-in with center island</figcaption></figure>
      <figure><img src="<?php echo ccg_asset( 'img/work/closet-vanity-desk.jpg' ); ?>" alt="Closet shelving with a built-in vanity desk"><figcaption>Shelving with a built-in vanity</figcaption></figure>
      <figure><img src="<?php echo ccg_asset( 'img/work/walkin-open-drawer.jpg' ); ?>" alt="Walk-in closet with shoe walls and open drawer"><figcaption>Shoe walls and center drawers</figcaption></figure>
      <figure><img src="<?php echo ccg_asset( 'img/work/mudroom-pine-bench.jpg' ); ?>" alt="Pine mudroom bench with hooks and drawers"><figcaption>Mudroom bench with hooks and drawers</figcaption></figure>
      <figure><img src="<?php echo ccg_asset( 'img/work/walkin-mid-build.jpg' ); ?>" alt="Walk-in closet shelving mid-build under a chandelier"><figcaption>Mid-build</figcaption></figure>
    </div>
    <details class="more-work">
      <summary class="btn">See more projects</summary>
      <div class="masonry" data-gallery>
        <figure><button type="button" aria-label="Enlarge: Walk-in with open bag shelving"><img src="<?php echo ccg_asset( 'img/work/walkin-real-bags.jpg' ); ?>" alt="Walk-in with open bag shelving" loading="lazy"></button><figcaption>Walk-in with open bag shelving</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Lit reach-in with shoe tower"><img src="<?php echo ccg_asset( 'img/work/reach-in-lit.jpg' ); ?>" alt="Lit reach-in with shoe tower" loading="lazy"></button><figcaption>Lit reach-in with shoe tower</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Glass-front cabinets with lighting"><img src="<?php echo ccg_asset( 'img/work/walkin-glass-doors.jpg' ); ?>" alt="Glass-front cabinets with lighting" loading="lazy"></button><figcaption>Glass-front cabinets with lighting</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Island walk-in under skylights"><img src="<?php echo ccg_asset( 'img/work/walkin-skylights-island.jpg' ); ?>" alt="Island walk-in under skylights" loading="lazy"></button><figcaption>Island walk-in under skylights</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Center drawer bank"><img src="<?php echo ccg_asset( 'img/work/closet-center-drawers.jpg' ); ?>" alt="Center drawer bank" loading="lazy"></button><figcaption>Center drawer bank</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Drawer bank with walnut top"><img src="<?php echo ccg_asset( 'img/work/walkin-walnut-top.jpg' ); ?>" alt="Drawer bank with walnut top" loading="lazy"></button><figcaption>Drawer bank with walnut top</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Walk-in with chandelier"><img src="<?php echo ccg_asset( 'img/work/walkin-chandelier.jpg' ); ?>" alt="Walk-in with chandelier" loading="lazy"></button><figcaption>Walk-in with chandelier</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Reach-in behind double doors"><img src="<?php echo ccg_asset( 'img/work/reach-in-doors.jpg' ); ?>" alt="Reach-in behind double doors" loading="lazy"></button><figcaption>Reach-in behind double doors</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Hanging, shelves and drawers"><img src="<?php echo ccg_asset( 'img/work/walkin-hanging-drawers.jpg' ); ?>" alt="Hanging, shelves and drawers" loading="lazy"></button><figcaption>Hanging, shelves and drawers</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Double rod reach-in"><img src="<?php echo ccg_asset( 'img/work/reach-in-double-rod.jpg' ); ?>" alt="Double rod reach-in" loading="lazy"></button><figcaption>Double rod reach-in</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Reach-in with drawer bank"><img src="<?php echo ccg_asset( 'img/work/reach-in-drawer-bank.jpg' ); ?>" alt="Reach-in with drawer bank" loading="lazy"></button><figcaption>Reach-in with drawer bank</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Center drawers and long hanging"><img src="<?php echo ccg_asset( 'img/work/walkin-center-drawers.jpg' ); ?>" alt="Center drawers and long hanging" loading="lazy"></button><figcaption>Center drawers and long hanging</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Shoe shelving and baskets"><img src="<?php echo ccg_asset( 'img/work/walkin-dark-frame.jpg' ); ?>" alt="Shoe shelving and baskets" loading="lazy"></button><figcaption>Shoe shelving and baskets</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Walk-in built around a safe"><img src="<?php echo ccg_asset( 'img/work/walkin-gun-safe.jpg' ); ?>" alt="Walk-in built around a safe" loading="lazy"></button><figcaption>Walk-in built around a safe</figcaption></figure>
        <figure><button type="button" aria-label="Enlarge: Island walk-in with soft-close drawers"><img src="<?php echo ccg_asset( 'img/work/walkin-island-drawers.jpg' ); ?>" alt="Island walk-in with soft-close drawers" loading="lazy"></button><figcaption>Island walk-in with soft-close drawers</figcaption></figure>
      </div>
    </details>
  </div>
</section>
<div class="lightbox" role="dialog" aria-label="Photo"><button type="button">Close</button><img alt=""></div>

<section class="section mist" id="reviews">
  <div class="wrap">
    <div class="head-split">
      <div><p class="eyebrow">Reviews</p><h2>What customers say.</h2></div>
      <p class="rating-line"><span class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span> <span class="todo">[Rating]</span> average from <span class="todo">[number]</span> reviews</p>
    </div>
    <div class="reviews">
      <figure class="review"><div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>[Customer review. Paste a real review from Google or Facebook here.]</blockquote><cite><span class="todo">[Customer name]</span>, walk-in closet</cite></figure>
      <figure class="review"><div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>[Customer review. Ideally one that mentions the design meeting or the build team.]</blockquote><cite><span class="todo">[Customer name]</span>, <span class="todo">[project]</span></cite></figure>
      <figure class="review"><div class="stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>[Customer review. A mudroom or smaller closet rounds out the set.]</blockquote><cite><span class="todo">[Customer name]</span>, <span class="todo">[project]</span></cite></figure>
    </div>
  </div>
</section>


<section class="section dark contact" id="contact">
  <div class="wrap">
    <div>
      <p class="eyebrow">Free consultation</p>
      <h2 style="margin-top:14px">Book a free <em>design consultation.</em></h2>
      <p class="lede" style="margin-top:18px;max-width:44ch">We come to you to talk through your goals, take measurements and outline a plan. If you have already made a design online, mention it and we will bring it along.</p>
      <dl>
        <dt>Phone</dt><dd><a href="tel:+15055461788">(505) 546-1788</a></dd>
        <dt>Email</dt><dd><a href="mailto:richard@customclosetguys.com">richard@customclosetguys.com</a></dd>
        <dt>Service area</dt><dd>Albuquerque, Santa Fe and surrounding communities</dd>
        <dt>Hours</dt><dd><?php echo ccg_hours(); ?></dd>
      </dl>
    </div>
    <div>
      <?php ccg_form_open(); ?>
        <div><label for="cf-name">Name</label><input id="cf-name" name="name" type="text" autocomplete="name" required></div>
        <div><label for="cf-phone">Phone</label><input id="cf-phone" name="phone" type="tel" autocomplete="tel" required></div>
        <div class="full"><label for="cf-email">Email</label><input id="cf-email" name="email" type="email" autocomplete="email"></div>
        <div class="full"><label for="cf-space">Which space?</label>
          <select id="cf-space" name="space"><option>Walk-in closet</option><option>Smaller / reach-in closet</option><option>Mudroom or entryway</option><option>Garage</option><option>Cabinetry</option><option>Something else</option></select></div>
        <div class="full"><label for="cf-msg">Tell us about it</label><textarea id="cf-msg" name="message" placeholder="Rough size of the space, what is not working now, any styles you like"></textarea></div>
        <div class="full hp" aria-hidden="true"><label for="cf-web">Leave this empty</label><input id="cf-web" name="website" type="text" tabindex="-1" autocomplete="off"></div>
        <div class="full"><button class="btn gold" type="submit">Request my consultation</button></div>
      </form>
      <div class="form-done<?php echo ccg_sent() ? ' show' : ''; ?>" tabindex="-1">Thanks, we have your request. Richard will call to set up your design meeting.</div>
    </div>
  </div>
</section>

<?php get_footer();
